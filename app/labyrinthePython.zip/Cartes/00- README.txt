Editeur de carte pour le Jeu du Labyrinthe

----------------------------------------------------------
Toutes les cartes devront �tre cr�es de la m�me mani�re :

--SYMBOLES UTILISES--
O pour les murs
/ pour les portes
X pour le personnage (il ne peut y en avoir qu'un)
= pour la sortie (il ne peut aussi y en avoir qu'une)
  un espace pour les couloirs

--PRESENTATION DES CARTES--

La carte doit �tre justifi�e � gauche
Il ne doit y avoir qu'une carte par fichier

Exemple : 

OOOOOOOOOOO
OX        O
OOOOOOOOO O
O O    O  O
O OOO OO  O
O  O      O
OO OO/OOOOO
O  OO O   O
O O   O O =
O O OOO/OOO
O   O     O
O/OOOOOOO/O
O         O
OOOOOOOOOOO