----------------------------------------------------------
                      JEU LABYRINTHE
----------------------------------------------------------
Cod� par Lo�ck Brouard 
Gr�ce au MOOC de Vincent Le Goff sur OpenClassRoom.


--BUT DU JEU--

Vous �tes enferm� dans un labyrinthe et tr�s naturellement... vous devez sortir :)

--EDITER UNE CARTE--

Pour �diter une carte il vous suffit d'aller dans le repertoire Cartes et de modifier ou de cr��r un fichier texte.

--JOUER !--

Pour lancer le jeu il suffit de lancer le fichier Labyrinthe.exe


--SYMBOLES UTILISES--

O pour les murs
/ pour les portes
X pour le personnage (il ne peut y en avoir qu'un)
= pour la sortie (il ne peut aussi y en avoir qu'une)
  un espace pour les couloirs 

Exemple
OOOOOOOOOOO
OX        O
OOOOOOOOO O
O O    O  O
O OOO OO  O
O  O      O
OO OO/OOOOO
O  OO O   O
O O   O O =
O O OOO/OOO
O   O     O
O/OOOOOOO/O
O         O
OOOOOOOOOOO